// Orienteering.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include<map>
#include<vector>
#include<iostream>
using namespace std;

struct Coordinate
{
	int x;
	int y;
	bool operator <(const Coordinate& other) const
	{
		if (x < other.x)        //���Ͱ���������
		{
			return true;
		}
		else if (x == other.x)  //���������ͬ������������������
		{
			return y < other.y;
		}

		return false;
	}
	Coordinate(int xx,int yy)
	{
		x=xx;
		y=yy;
	}
};
struct Node
{
	bool m_IsTraversal;
	char m_Type;
	int  m_PathLength;
	int  m_NumberCheckPoint;
	int  m_CheckPointLength;
	Node(bool isTraversal,char type,int pathLength)
	{
		isTraversal=m_IsTraversal;
		m_Type=type;
		m_PathLength=pathLength;
		m_NumberCheckPoint=0;
		m_CheckPointLength=0;
	}
};
typedef pair <Coordinate, Node> NodePair;
map<Coordinate,Node> m_mapNodes;
Coordinate m_Start(0,0);
vector<Coordinate> m_CheckPoint;
int m_MixPathLenth=INT_MAX;
int m_CountCheckPoint=1;
int m_TotalCheckPoint=0;
void Travers(map<Coordinate,Node> mapNodes,Coordinate inputCoordinate);
void InitSpecialNode(char inputChar,Coordinate inputCoordinate,Node &node)
{
	if(inputChar=='S')
	{
		m_Start=inputCoordinate;
	}
	if(inputChar=='@')
	{
		m_CheckPoint.push_back(inputCoordinate);
		node.m_NumberCheckPoint=m_CountCheckPoint;
		m_CountCheckPoint=(m_CountCheckPoint<<1);
		m_TotalCheckPoint=(m_TotalCheckPoint<<1)+1;
	}
}
void Input()
{
	int width,height,column=0,row=0;
	cin>>width>>height;
	char inputChar;
	while(row<height)
	{
		column=0;
		while(column<width)
		{
			cin>>inputChar;
			Coordinate inputCoordinate(column,row);
			Node inputNode(false,inputChar,0);
			InitSpecialNode(inputChar,inputCoordinate,inputNode);
			m_mapNodes.insert(NodePair(inputCoordinate,inputNode));
			column++;
		}
		row++;
	}
}
void FourDirectionTravers( map<Coordinate,Node> &mapNodes, Coordinate coordinate,Coordinate parentCoordinate) 
{
	map<Coordinate,Node>::iterator itMapNodes;
	itMapNodes=mapNodes.find(coordinate);
	if(itMapNodes==mapNodes.end()||itMapNodes->second.m_Type=='#')
		return;
	if(itMapNodes->second.m_IsTraversal==true&&(mapNodes.at(parentCoordinate).m_CheckPointLength==itMapNodes->second.m_CheckPointLength))
		return;

	itMapNodes->second.m_PathLength=mapNodes.at(parentCoordinate).m_PathLength;
	itMapNodes->second.m_CheckPointLength=mapNodes.at(parentCoordinate).m_CheckPointLength;
	map<Coordinate,Node> maDirectionNodes=mapNodes;
	Travers(maDirectionNodes,coordinate);
}

void Travers(map<Coordinate,Node> mapNodes,Coordinate inputCoordinate)
{
	map<Coordinate,Node>::iterator itMapNodes;
	itMapNodes=mapNodes.find(inputCoordinate);
	itMapNodes->second.m_IsTraversal=true;
	itMapNodes->second.m_PathLength++;
	if(itMapNodes->second.m_Type=='@')
	{
		itMapNodes->second.m_CheckPointLength=itMapNodes->second.m_CheckPointLength|itMapNodes->second.m_NumberCheckPoint;
	}
	if(itMapNodes->second.m_Type=='G'&&(itMapNodes->second.m_CheckPointLength==m_TotalCheckPoint))
	{
		if(itMapNodes->second.m_PathLength>=m_MixPathLenth)
			return;
		m_MixPathLenth=itMapNodes->second.m_PathLength;
	}else
	{
		Coordinate upCoordinate(inputCoordinate.x,inputCoordinate.y-1)
			      ,downCoordinate(inputCoordinate.x,inputCoordinate.y+1)
				  ,leftCoordinate(inputCoordinate.x-1,inputCoordinate.y)
				  ,rightCoordinate(inputCoordinate.x+1,inputCoordinate.y);

		FourDirectionTravers(mapNodes, upCoordinate,inputCoordinate);
	    FourDirectionTravers(mapNodes, rightCoordinate,inputCoordinate);
		FourDirectionTravers(mapNodes, downCoordinate,inputCoordinate);
		FourDirectionTravers(mapNodes, leftCoordinate,inputCoordinate);

	}
}
void Process()
{
	Input();
	Travers(m_mapNodes,m_Start);
}
int _tmain(int argc, _TCHAR* argv[])
{

	Process();
	cout<<"path length:"<<m_MixPathLenth-1<<endl;
	return 0;
}

